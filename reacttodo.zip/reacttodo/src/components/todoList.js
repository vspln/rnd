import React from 'react';
import logo from '../logo.svg';
import './todoList.css';
import Box from '@material-ui/core/Box';
import TextField from '@material-ui/core/TextField';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import ListItemSecondaryAction from '@material-ui/core/ListItemSecondaryAction';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import Divider from '@material-ui/core/Divider';

class Main extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            newItem: "",
            list: []
        }
    }

    addItem(todoValue) {
        if (todoValue !== "") {
            const newItem = {
                id: Date.now(),
                value: todoValue,
                isDone: false
            };
            const list = [...this.state.list];
            list.push(newItem);

            this.setState({
                list,
                newItem: ""
            });
        }
    }

    deleteItem(id) {
        const list = [...this.state.list];
        const updatedlist = list.filter(item => item.id !== id);
        this.setState({ list: updatedlist })
    }

    updateInput(TextField) {
        this.setState({ newItem: TextField });
    }

    render() {
        return (
            <div>
                <Box width="50%" className="container" mx="auto">
                    <img src={logo} alt="logo" className="logo" />
                    <Box width="50%" align="center" p={1} mx="auto" my={1}>
                        <TextField
                            label="write a Todo"
                            required
                            value={this.state.newItem}
                            onChange={e => this.updateInput(e.target.value)}
                        />
                    
                        <button
                            className="AddBtn"
                            onClick={() => this.addItem(this.state.newItem)}
                            disabled={!this.state.newItem.length}
                        >
                            Add Todo
                        </button>
                    </Box>
                    <Box p={1}>
                        <List>
                            {this.state.list.map(item => {
                                return (
                                    <React.Fragment>
                                        <ListItem key={item.id}>
                                            <ListItemText
                                                primary={item.value}
                                            />
                                            <ListItemSecondaryAction>
                                                <IconButton edge="end" onClick={() => this.deleteItem(item.id)} aria-label="delete">
                                                    <DeleteIcon />
                                                </IconButton>
                                            </ListItemSecondaryAction>
                                        </ListItem>
                                        <Divider light />
                                    </React.Fragment>
                                );
                            })}
                        </List>
                    </Box>
                </Box>
            </div>
        );
    }
}

export default Main;