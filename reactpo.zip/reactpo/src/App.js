import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './components/Home';
import Navbar from './components/Navbar';
import Create from './components/Create';
import PODetails from './components/PODetails';

const useStyles = makeStyles({
  root: {
    width: '100%',
    maxWidth: 600,
    margin: '0 auto',
    padding: '8px 16px 16px',
    background: '#f6f7f9'
  },
});

function App() {
  const classes = useStyles();
  return (
    <Router>
      <div className={classes.root}>
        <Navbar />
          <Switch>
            <Route exact path="/">
              <Home />
            </Route>
            <Route path="/create">
              <Create />
            </Route>
            <Route path="/pos/:id">
              <PODetails />
            </Route>
          </Switch>
      </div>
    </Router>
  );
}

export default App;