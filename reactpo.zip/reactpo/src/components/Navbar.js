import React from 'react';
import { Link } from "react-router-dom";
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    '& a': {
      padding: '8px',
      background: '#fff',
      margin: '8px 8px 16px',
      textDecoration: 'none',
      boxShadow: '1px 3px 5px rgba(0,0,0,0.1)',
    },
    '& a:hover': {
      textDecoration: 'none',
      boxShadow: '1px 3px 5px rgba(0,0,0,0.2)',
    }
  },
}));

const Navbar = () => {
  const classes = useStyles();
  return (
    <Typography className={classes.root}>
      <Link to="/">PO List</Link>
      <Link to="/create">Create PO</Link>
    </Typography>
  );
}
 
export default Navbar;