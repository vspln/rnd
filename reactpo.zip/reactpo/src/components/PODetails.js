import React from 'react';
import { useHistory, useParams } from "react-router-dom";
import useFetch from "./useFetch";
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

const useStyles = makeStyles({
  root: {
    
  },
});

const PODetails = () => {
  const classes = useStyles();
  const { id } = useParams();
  const { data: po, error, isPending } = useFetch('http://localhost:8000/pos/' + id);
  const history = useHistory();

  const handleClick = () => {
    fetch('http://localhost:8000/pos/' + po.id, {
      method: 'DELETE'
    }).then(() => {
      history.push('/');
    }) 
  }

  return (
    <Card className={classes.root}>
      { isPending && <div>Loading...</div> }
      { error && <div>{ error }</div> }
      { po && (
        <CardContent>
          <Typography variant="subtitle1" gutterBottom>
            { po.title }
          </Typography>
          <Typography variant="caption" display="block" gutterBottom>
            Creater { po.author }
          </Typography>
          <Typography variant="subtitle2" gutterBottom>
            { po.body }
          </Typography>
          <Typography component="button" variant="contained" onClick={handleClick}>Delete</Typography>
        </CardContent>
      )}
    </Card>
  );
}
 
export default PODetails;