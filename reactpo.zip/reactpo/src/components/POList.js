import React from 'react';
import { Link } from 'react-router-dom';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

const useStyles = makeStyles({
  root: {
    '& a': {
      display: 'block',
      padding: '8px',
      textDecoration: 'none',
      background: '#f6f7f9',
      boxShadow: '1px 3px 5px rgba(0,0,0,0.1)',
    },
    '& a:hover': {
      textDecoration: 'none',
      boxShadow: '1px 3px 5px rgba(0,0,0,0.2)',
    }
  },
});

const POList = ({ pos }) => {
  const classes = useStyles();
  return (
    <Card className={classes.root} elevation={0}>
      {pos.map(po => (
        <CardContent key={po.id} >
          <Link to={`/pos/${po.id}`}>
            <Typography variant="subtitle1" gutterBottom>
              { po.title }
            </Typography>
            <Typography variant="caption" display="block" gutterBottom>
              Creater { po.author }
            </Typography>
          </Link>
        </CardContent>
      ))}
    </Card>
  );
}
 
export default POList;