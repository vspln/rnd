import React from 'react';
import POList from "../components/POList";
import useFetch from "../components/useFetch";
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  root: {
    
  },
});

const Home = () => {
  const classes = useStyles();
  const { error, isPending, data: pos } = useFetch('http://localhost:8000/pos')

  return (
    <div className={classes.root}>
      { error && <div>{ error }</div> }
      { isPending && <div>Loading...</div> }
      { pos && <POList pos={pos} /> }
    </div>
  );
}
 
export default Home;