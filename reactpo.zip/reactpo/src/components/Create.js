import React from "react";
import { useState } from "react";
import { useHistory } from "react-router-dom";
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexDirection: 'column',
    '& > *': {
      marginBottom: theme.spacing(2),
    },
    '& button': {
      padding: '6px 12px',
    }
  },
}));

const Create = () => {
  const classes = useStyles();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [author, setAuthor] = useState('User1');
  const history = useHistory();

  const handleSubmit = (e) => {
    e.preventDefault();
    const po = { title, body, author };

    fetch('http://localhost:8000/pos/', {
      method: 'POST',
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(po)
    }).then(() => {
      history.push('/');
    })
  }

  return (
    <div className={classes.root}>
      <Typography variant="subtitle1" gutterBottom>
        Create PO
      </Typography>
      <form className={classes.root} onSubmit={handleSubmit}>
        <TextField
          label="PO Title"
          type="text" 
          required 
          variant="outlined"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <TextField
          label="PO Desc"
          required
          multiline
          rows={4}
          variant="outlined"
          value={body}
          onChange={(e) => setBody(e.target.value)}
        />
        <TextField
          select
          label="Creater"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
        >
          <MenuItem value="User1">User1</MenuItem>
          <MenuItem value="User2">User2</MenuItem>
        </TextField>
        <Typography component="button" variant="contained">Create</Typography>
      </form>
    </div>
  );
}
 
export default Create;